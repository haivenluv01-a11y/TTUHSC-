document.addEventListener('DOMContentLoaded', function(){
  const env = document.getElementById('envelope');
  const card = document.getElementById('card');
  const audio = new Audio('music_pop.wav');
  audio.loop = true;
  let opened = false;

  function openEnvelope(){
    if(opened) return;
    opened = true;
    env.classList.add('open');
    // reveal the card after flap opens
    setTimeout(()=> {
      card.classList.remove('hidden');
      card.classList.add('visible');
      try{ audio.play(); } catch(e){ /* autoplay blocked; user can press RSVP to play */ }
    }, 700);
  }

  env.addEventListener('click', openEnvelope);
  // also allow keyboard
  env.setAttribute('tabindex','0');
  env.addEventListener('keydown', function(e){ if(e.key==='Enter' || e.key===' ') openEnvelope(); });

  // If user clicks RSVP, try to ensure audio plays (user gesture)
  const rsvp = document.querySelector('.rsvp');
  rsvp.addEventListener('click', function(){ audio.play().catch(()=>{}); });
});
